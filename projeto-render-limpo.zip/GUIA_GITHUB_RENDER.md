# Guia para subir o projeto no GitHub e publicar na Render

O erro **"Yowza, that’s a lot of files. Try uploading fewer than 100 at a time."** acontece porque o envio pelo site do GitHub limita o upload manual em lotes pequenos. No seu caso, o caminho correto é **usar Git pelo terminal** em vez de arrastar arquivos pelo navegador.

## O que foi ajustado na cópia limpa

Foi preparada uma cópia do seu projeto em `app/` com as seguintes correções:

| Ajuste | Motivo |
|---|---|
| Remoção de `.workspace/` | Essa pasta é local e não deve ir para o repositório |
| Remoção de `.env` | Evita expor chaves e dados sensíveis |
| Criação de `.env.example` | Facilita configurar o ambiente na hospedagem |
| Atualização do `.gitignore` | Evita enviar arquivos temporários, cache e segredos |

## Como subir no GitHub

Primeiro, crie um repositório vazio no GitHub. Depois, no terminal da pasta `app`, rode os comandos abaixo, trocando a URL pela do seu repositório.

```bash
git init
git add .
git commit -m "Primeiro commit"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

Se o GitHub pedir autenticação, você pode fazer login pelo navegador ou usar token pessoal.

## Como publicar na Render

Como o projeto é um **frontend Vite/React**, o tipo mais adequado na Render é **Static Site**.

Use estas configurações:

| Campo na Render | Valor |
|---|---|
| Environment | `Node` |
| Build Command | `npm install && npm run build` |
| Publish Directory | `dist` |

## Variáveis de ambiente na Render

No painel da Render, adicione as variáveis que estão no arquivo `.env.example`.

| Variável | Observação |
|---|---|
| `VITE_SUPABASE_PROJECT_ID` | ID do projeto no Supabase |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Chave pública do Supabase |
| `VITE_SUPABASE_URL` | URL do projeto no Supabase |

## Observação importante sobre pagamento

Se a sua **API de pagamento** estiver realmente no frontend, isso pode expor credenciais sensíveis. O ideal é que pagamentos fiquem em um **backend** ou **função server-side**. Se hoje você usa apenas integrações públicas no navegador, revise isso antes de ir para produção.

## Validação feita

O projeto foi testado localmente com build de produção e compilou com sucesso.

| Verificação | Resultado |
|---|---|
| Instalação de dependências | OK |
| Build de produção | OK |
| Saída gerada em `dist/` | OK |

## Próximo passo recomendado

Suba a pasta `app` no GitHub usando Git. Depois, conecte o repositório na Render como **Static Site** e informe as variáveis de ambiente.

Se quiser, no próximo passo eu posso te ajudar a:

1. revisar se sua integração de pagamento está segura para produção;
2. preparar um passo a passo exato para criar o serviço na Render;
3. organizar o repositório para deploy contínuo.
